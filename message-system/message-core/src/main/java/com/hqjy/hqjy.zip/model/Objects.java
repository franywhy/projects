package com.hqjy.model;

import java.io.Serializable;

/**
 * Created by Administrator on 2017/6/27 0027.
 */
public class Objects extends Object implements Serializable{
    private static final long serialVersionUID = 1L;
}
