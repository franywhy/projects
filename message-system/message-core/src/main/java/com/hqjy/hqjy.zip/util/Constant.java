package com.hqjy.util;

/**
 * Created by Administrator on 2017/12/21 0021.
 */
public class Constant {

    public final static String WAIT_REDIS = "_wait";
    public final static String MESSAGE_REDIS = "_msg";
    public final static String USER_REDIS = "_user";

    public final static int SPLIT_LIST_SIZE = 20000;

    public final static int THREAD_POOL_CORE_SIZE = 20;
    public final static int THREAD_POOL_MAX_SIZE = 1100;
    public final static int THREAD_POOL_ALIVE_TIME = 60;
    public final static int THREAD_POOL_QUEUE = 100000;

    public final static int COMPARE_MINITUS = 2; //日期相差的分钟数

    public static void main(String[] args) {
        String str = "asdfasdfa"+WAIT_REDIS;
        String [] strs = str.split("_wait");
        System.out.println(strs[0].toString());
    }
}
