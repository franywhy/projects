package com.hqjy.util;

import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Created by baobao on 2017/11/16 0016.
 */
public class StringUtils extends org.apache.commons.lang.StringUtils {

    public static String objToJsonStr(Object obj){
        /*JSONArray json = JSONArray.fromObject(obj);
        return json.toString();*/
        Gson gson = new Gson();
        return gson.toJson(obj);

    }

    public static Object strToObj(String str,Class cls){
        Gson gson = new Gson();
        return gson.fromJson(str,cls);

    }

    public static List listsToArray(List list ,int idx ){
        int size = list.size() ;
        List lists = new ArrayList();
        if (size<=idx) {
            lists.add(list);
            return lists;
        }
        int a = (size/idx);
        for (int i = 0; i < a; i++) {
            int start = i*idx;
            int end = (i+1)*idx;
            if (end>size) {
                end = size-1;
            }
            lists.add(list.subList((i*idx),((i+1)*idx)));

        }
        return lists;
    }
    public static String getUnquie(){
        String chars = "abcdefghijklmnopqrstuvwxyz1234567890";

        UUID uuid = UUID.randomUUID();
        String key = uuid.toString().replaceAll("-", String.valueOf(chars.charAt((int)(Math.random() * 36)))).toUpperCase();
        key = key + DateUtils.dateToString(DateUtils.getNowDate(), "yyyyMMddHHmmss");
        return key;

    }


}
